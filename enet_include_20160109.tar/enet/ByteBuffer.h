/*
 * ByteBuffer.h
 *
 *  Created on: May 6, 2013
 *      Author: LiuYongJin
 */
#ifndef _BYTEBUFFER_H_
#define _BYTEBUFFER_H_
#include <assert.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

namespace enet
{

class ByteBuffer
{
public:
    ByteBuffer();
    ByteBuffer(uint32_t capacity);
    ByteBuffer(const ByteBuffer &byte_buffer);
    ByteBuffer& operator=(const ByteBuffer &byte_buffer);
    virtual ~ByteBuffer();

    char* Buffer() const;         //缓冲区首地址;
    uint32_t Size() const;        //缓冲区数据大小;
    uint32_t Capacity() const;    //缓冲区容量
    uint32_t Clear();             //清空缓冲区,返回原来数据大小

    uint32_t RemainSize();        //空闲缓冲区大小
    char* RemainBuffer(uint32_t need_size=0);  //返回空闲缓冲区的指针(确保该空闲缓冲区大小不小于need_size),没有空闲缓冲区返回NULL
    uint32_t AddSize(uint32_t size);           //缓冲区数据增大size字节,返回增大之后数据大小(往缓冲区中添加数据后,需要调用本方法加大数据大小,否则添加数据无效)

    uint32_t PushFront(uint32_t size, const char *data); //往缓冲区前端添加size字节的data.返回最后的数据大小
    uint32_t PopFront(uint32_t size, char *data=NULL);   //从缓冲区前端弹出size字节数据,如果data非空,将这些数据保存到data(data大小不能小于size字节).返回弹出的数据大小(有可能小于size)

    uint32_t PushBack(const char *data);                 //往缓冲区尾端添加以'\0'结尾的data(不包括'\0')
    uint32_t PushBack(uint32_t size, const char *data);  //往缓冲区尾端添加size字节的data.返回最后数据大小
    uint32_t PopBack(uint32_t size, char *data=NULL);    //从缓冲区尾端弹出size字节的数据,如果data非空,将这些数据保存到data(data大小不能小于size字节).返回弹出的数据大小(有可能小于size)

    uint32_t MoveTo(ByteBuffer &byte_buffer);            //将数据迁移到byte_buffer,返回迁移的数据大小(当byte_buffer没有分配空间的时候, 本身的buffer会被迁移到byte_buff中!!!)
private:
	char *m_buffer;      //数据缓冲区
	uint32_t m_capacity; //缓冲区的容量
	uint32_t m_size;     //缓冲区数据大小
};

inline
ByteBuffer::ByteBuffer()
    :m_size(0)
    ,m_capacity(0)
    ,m_buffer(NULL)
{
}

inline
ByteBuffer::ByteBuffer(uint32_t capacity)
{
    if(capacity == 0)
        ByteBuffer();
    m_size = 0;
    m_capacity = capacity;
    m_buffer = (char*)malloc(capacity);
    assert(m_buffer != NULL);
}

inline
ByteBuffer::ByteBuffer(const ByteBuffer &byte_buffer)
{
    m_size = 0;
    m_capacity = 0;
    m_buffer = NULL;

    if(byte_buffer.Size() > 0)
    {
        char *buffer = RemainBuffer(byte_buffer.Size());
        memcpy(buffer, byte_buffer.Buffer(), byte_buffer.Size());
        m_size = byte_buffer.Size();
    }
}

inline
ByteBuffer::~ByteBuffer()
{
    if(m_buffer != NULL)
        free(m_buffer);
    m_size = 0;
    m_capacity = 0;
    m_buffer = 0;
}

inline
char* ByteBuffer::Buffer() const
{
    return m_buffer;
}

inline
uint32_t ByteBuffer::Size() const
{
    return m_size;
}

inline
uint32_t ByteBuffer::Capacity() const
{
    return m_capacity;
}

inline
uint32_t ByteBuffer::AddSize(uint32_t size)
{
    assert(m_size+size <= m_capacity);
    m_size += size;
    return m_size;
}

inline
uint32_t ByteBuffer::Clear()
{
    uint32_t size = m_size;
    m_size = 0;
    return size;
}

inline
uint32_t ByteBuffer::RemainSize()
{
    return m_capacity-m_size;
}

inline
char* ByteBuffer::RemainBuffer(uint32_t need_size/*=0*/)
{
    if(need_size == 0)
    {
        if(m_capacity > m_size)
            return m_buffer+m_size;
        else
            return NULL;
    }
    if(need_size+m_size > m_capacity)
    {
        uint32_t new_capacity = need_size+m_size;
        if(new_capacity % 1024)  //1k的整数倍
            new_capacity = ((new_capacity>>10)+1)<<10;
            //new_capacity += (1024-new_capacity%1024);
        char *new_buff = (char *)realloc(m_buffer, new_capacity);
        assert(new_buff != NULL);
        m_buffer = new_buff;
        m_capacity = new_capacity;
    }
    return m_buffer+m_size;
}

inline
uint32_t ByteBuffer::PushFront(uint32_t size, const char *data)
{
    if(size==0 || data==NULL)
        return m_size;

    //注意内存空间重叠的情况!!!
    if(size+m_size <= m_capacity)
    {
        char *ptr_src = m_buffer+m_size;
        char *ptr_dst = m_buffer+m_size+size;
        while(ptr_src > m_buffer)
            *--ptr_dst = *--ptr_src;
        memcpy(m_buffer, data, size);
        m_size += size;
    }
    else  //空间不够
    {
        uint32_t new_capacity = size+m_size;
        if(new_capacity % 1024)  //1k的整数倍
            new_capacity = ((new_capacity>>10)+1)<<10;
            //new_capacity += (1024-new_capacity%1024);
        char *new_buff = (char *)malloc(new_capacity);
        assert(new_buff != NULL);

        char *ptr_src = m_buffer+m_size;
        char *ptr_dst = new_buff+m_size+size;
        while(ptr_src > m_buffer)
            *--ptr_dst = *--ptr_src;
        free(m_buffer);

        m_buffer = new_buff;
        m_capacity = new_capacity;
        memcpy(m_buffer, data, size);
        m_size += size;
    }
    return m_size;
}

inline
uint32_t ByteBuffer::PopFront(uint32_t size, char *data/*=NULL*/)
{
    if(size > m_size)
        size = m_size;
    m_size -= size;
    if(size > 0)
    {
        if(data != NULL)
            memcpy(data, m_buffer, size);
        //if(m_size > 0)
        //    memcpy(m_buffer, m_buffer+size, m_size);  //有问题?有时数据会不对

        char *dst = m_buffer;
        char *src = m_buffer+size;
        for(uint32_t i=0; i<m_size; ++i)
        {
            dst[i] = src[i];
        }
    }
    return size;
}

inline
uint32_t ByteBuffer::PushBack(const char *data)
{
	if(data == NULL)
		return m_size;
	int size = strlen(data);
    if(size == 0)
        return m_size;

    char *buffer = RemainBuffer(size);
    assert(buffer != NULL);
    memcpy(buffer, data, size);
    m_size += size;
    return m_size;
}

inline
uint32_t ByteBuffer::PushBack(uint32_t size, const char *data)
{
    if(size==0 || data==NULL)
        return m_size;
    char *buffer = RemainBuffer(size);
    assert(buffer != NULL);
    memcpy(buffer, data, size);
    m_size += size;
    return m_size;
}

inline
uint32_t ByteBuffer::PopBack(uint32_t size, char *data/*=NULL*/)
{
    if(size > m_size)
        size = m_size;
    m_size -= size;
    if(size>= 0 || data!=NULL)
        memcpy(data, m_buffer+m_size, size);
    return size;
}

inline
ByteBuffer& ByteBuffer::operator=(const ByteBuffer &byte_buffer)
{
    if(this==&byte_buffer || byte_buffer.Size()==0)
        return *this;
    Clear();
    char *buffer = RemainBuffer(byte_buffer.Size());
    assert(buffer != NULL);
    memcpy(buffer, byte_buffer.Buffer(), byte_buffer.Size());
    m_size = byte_buffer.Size();
    return *this;
}

inline
uint32_t ByteBuffer::MoveTo(ByteBuffer &byte_buffer)
{
    if(m_size == 0)
        return m_size;
    if(byte_buffer.m_buffer == NULL)
    {
        byte_buffer.m_buffer = m_buffer;
        byte_buffer.m_size = m_size;
        byte_buffer.m_capacity = m_capacity;

        m_size = 0;
        m_capacity = 0;
        m_buffer = NULL;
        return byte_buffer.m_size;
    }

    byte_buffer.m_size = 0;
    char *buffer = byte_buffer.RemainBuffer(m_size);
    memcpy(buffer, m_buffer, m_size);
    byte_buffer.m_size = m_size;
    m_size = 0;
    return byte_buffer.m_size;
}

}//namespace
#endif //_BYTEBUFFER_H_
