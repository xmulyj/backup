/*
 * Packet.h
 *
 *  Created on: Oct 26, 2014
 *      Author: young
 */

#ifndef PACKET_H_
#define PACKET_H_

#include <netinet/in.h>
#include <stdint.h>
#include <stdio.h>

#include "utility/HttpTool.h"

namespace enet
{
//for 64bit
#ifndef htonll
#define htonll(x) (((uint64_t)(htonl((uint32_t)((x)&0xffffffff)))<<32) | htonl((uint32_t)(((x)>>32)&0xffffffff)))
#define ntohll(x) (((uint64_t)(ntohl((uint32_t)((x)&0xffffffff)))<<32) | ntohl((uint32_t)(((x)>>32)&0xffffffff)))
#endif

#define DEFAULT_PACKET_MAX_BODY_SIZE 1000000  //1M
typedef enum _packet_result_
{
    PACKET_INVALID,
    PACKET_WAIT,
    PACKET_OK,
}PacketResult;

#pragma pack(1)
typedef struct _default_header_
{
    char magic_num[4];  //分包的标识
    int32_t common_ret; //公用错误码.0表示没有错误,body_data有效, 否则body_data无效.
    uint32_t body_size; //协议数据长
    uint32_t cmd;       //命令号
    uint64_t tid;       //事务id(客户端忽略)
    uint32_t uid;       //用户id
}StDefaultPacket;
#pragma pack()

class Packet
{
public:
    virtual ~Packet(){}
    
    //返回头部长度,小于0错误码(tid=NULL表示没有设置tid,使用的是"PACK",否则使用的是"INTE")
    virtual int SetHead(char *head_buff, uint32_t data_size, uint32_t body_size, uint32_t cmd, uint32_t uid=0, uint64_t tid=0, int32_t common_ret=0);
    
    //返回动态的header_size
    //为什么在这里返回body_size,而不另外写个类似BodySize的方法返回body_size?因为为了适应动态协议(比如http), 一次获取需要的数据,而不需要在另外方法里面再处理一次
    virtual PacketResult IsValid(const char *data, uint32_t size, uint32_t &header_size, uint32_t &body_size);

    //cmd为什么不像上面的body_size直接返回?因为cmd的数据不一定放到协议头里面, 所以这边也传入header_size用于定位
    virtual uint32_t Cmd(const char *data, uint32_t header_size);  //获取命令号
    virtual uint64_t Tid(const char *data);  //获取事务id
    virtual int32_t CommonRet(const char *data);  //获取公共错误码

    virtual void SetTid(char *data, uint64_t tid);
    virtual void SetCommonRet(char *data, int32_t common_ret);
};
/*PS 1:HeaderSize方法返回的值跟IsValid返回返回的header_size的区别
 *1. 如果协议使用的是固定的头部,则二者的返回值是一致的
 *2. 如果协议的头部不是固定的, 则HeaderSize建议返回0, 以IsValid返回的header_size为准
 */
/*PS 2:这个协议怎么支持http协议:
 * 1. 继承这个类,子类的HeaderSize返回0
 * 2. IsValid中返回http协议头长度和body_size(即content-length的值)
 * 3. Cmd返回0(实际上不用处理cmd, 让OnPacket的实现来处理)
 */

inline
int Packet::SetHead(char *head_buff, uint32_t head_buff_size, uint32_t body_size, uint32_t cmd, uint32_t uid/*=0*/, uint64_t tid/*=0*/, int common_ret/*=0*/)
{
    int header_size = sizeof(StDefaultPacket);
    if(head_buff_size < header_size)
        return -1;
    if(body_size > DEFAULT_PACKET_MAX_BODY_SIZE)
        return -2;

    StDefaultPacket *header = (StDefaultPacket*)head_buff;
    //MagicNum
    header->magic_num[0] = 'P';
    header->magic_num[1] = 'A';
    header->magic_num[2] = 'C';
    header->magic_num[3] = 'K';
    //CommonRet
    header->common_ret = htonl(common_ret);
    //Tid
    header->tid = htonll(tid);
    //BodySize
    header->body_size = htonl(body_size);
    //Cmd
    header->cmd = htonl(cmd);
    header->uid = htonl(uid);
    return header_size;
}

inline
PacketResult Packet::IsValid(const char *data, uint32_t size, uint32_t &header_size, uint32_t &body_size)
{
    if(size < sizeof(StDefaultPacket))
        return PACKET_WAIT;
    if(data[0] == 'P'
       && data[1] == 'A'
       && data[2] == 'C'
       && data[3] == 'K')  //Packet
    {
        header_size = sizeof(StDefaultPacket);
        StDefaultPacket *header = (StDefaultPacket*)data;
        uint32_t temp = ntohl(header->body_size);
        if(temp > DEFAULT_PACKET_MAX_BODY_SIZE)
            return PACKET_INVALID;
        body_size = temp;
        return PACKET_OK;
    }

    return PACKET_INVALID;
}

inline
uint32_t Packet::Cmd(const char *data, uint32_t header_size)
{
    StDefaultPacket *header = (StDefaultPacket*)data;
    return ntohl(header->cmd);
}

inline
uint64_t Packet::Tid(const char *data)
{
    StDefaultPacket *header = (StDefaultPacket*)data;
    return ntohll(header->tid);
}

inline
int32_t Packet::CommonRet(const char *data)
{
    StDefaultPacket *header = (StDefaultPacket*)data;
    return ntohl(header->common_ret);   
}

inline
void Packet::SetTid(char *data, uint64_t tid)
{
    StDefaultPacket *header = (StDefaultPacket*)data;
    header->tid = htonll(tid);
}

inline
void Packet::SetCommonRet(char *data, int32_t common_ret)
{
    StDefaultPacket *header = (StDefaultPacket*)data;
    header->common_ret = htonl(common_ret);
}

///////////////  Http Packet  ///////////////
#include "utility/HttpTool.h"
#define MAX_HTTP_HEADER_SIZE 1024
//支持GET/POST方法
class HttpPacket:public Packet
{
public:
    int SetHead(char *data, int data_size, uint32_t body_size, uint32_t cmd, uint32_t uid=0, uint64_t tid=0, int32_t common_ret=0){return 0;}
    PacketResult IsValid(const char *data, uint32_t size, uint32_t &header_size, uint32_t &body_size);
    uint32_t Cmd(const char *data, uint32_t header_size){return 0;}
    uint64_t Tid(const char *data){return 0;}
    int32_t CommonRet(const char *data){return 0;}
    void SetTid(char *data, uint64_t tid){}
    void SetCommonRet(char *data, int32_t common_ret){}
};

inline
PacketResult HttpPacket::IsValid(const char *data, uint32_t size, uint32_t &header_size, uint32_t &body_size)
{
    //检查http头部长度是否合法
    if(size > MAX_HTTP_HEADER_SIZE)
        return PACKET_INVALID;
    //判断是否收到完整的http头部
    int pos = HttpTool::Find(data, size, "\r\n\r\n");
    if(pos == -1)
        return PACKET_WAIT;
    header_size = pos+4;
    body_size = 0;

    HttpMethod http_method = HttpTool::GetMethod(data);
    if(http_method == HTTP_METHOD_POST)
    {
        pos = HttpTool::Find(data, size, "content-length:", true);
        if(pos == -1)
            return PACKET_INVALID;
        pos += 15;
        uint32_t content_length;
        if(sscanf(data+pos, "%d", &content_length) != 1)
        {
            return PACKET_INVALID;
        }
        if(content_length > DEFAULT_PACKET_MAX_BODY_SIZE)
        {
            return PACKET_INVALID;
        }
        body_size = content_length;
    }
    else if(http_method == HTTP_METHOD_GET)
    {
        body_size = 0;
    }
    else
    {
        return PACKET_INVALID;
    }

    return PACKET_OK;
}

}//namespace
#endif /* PACKET_H_ */
