/*
 * Process.h
 *
 *  Created on: 2014-7-14
 *      Author: yongjinliu
 */

#ifndef PROCESS_H_
#define PROCESS_H_

#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <stdio.h>

class Process
{
public:
    //返回值:-1:失败;0:子进程;大于0:父进程(和所有子进程)结束,返回的子进程个数;
    static int Fork(int num=1);
};

inline
int Process::Fork(int num/*=1*/)
{
    if(num <= 0)
        num = 1;

    int create_num = 0;
    for(int i=0; i<num; ++i)
    {
        pid_t pid = fork();
        if(pid < 0)
            break;
        else if(pid > 0)
            ++create_num;
        else
            return 0;
    }

    //wait for all child
    if(create_num == 0)
        return -1;

    int finish_num = 0;
    while(finish_num < create_num)
    {
        int status;
        pid_t pid = wait(&status);
        if(pid <= 0)  //被中断?(需要根据errno判断)
        {
            printf("WAIT ret(-1),error=%s\n", strerror(errno));
            continue;
        }
        if(WIFSTOPPED(status))  //暂停
        {
            continue;
        }
        if(WIFSIGNALED(status))  //调用exit
        {
            printf("SIG:status=%d\n", WTERMSIG(status));
            ++finish_num;
            continue;
        }
        if(WIFEXITED(status))    //信号
        {
            printf("EXIT:status=%d\n", WEXITSTATUS(status));
            ++finish_num;
            continue;
        }
    }

    return create_num;
}

#endif /* PROCESS_H_ */
