/*
 * TcpServerConf.h
 *
 *  Created on: Oct 26, 2014
 *      Author: young
 */

#ifndef TCPSERVERCONF_H_
#define TCPSERVERCONF_H_

#include <vector>
#include <string>
#include <set>
using std::string;
using std::vector;
using std::set;

#include "ConfReader.h"
#include "Logger.h"

namespace enet
{

class ConfSessionParam
{
public:
    int session_max_num;       //最大会话个数(默认100)
    int session_block;         //是否阻塞(默认0,非阻塞)
    int session_idle_time;     //空闲超时时间(默认3秒)
    int session_recv_timeout;  //接收超时时间(默认3s)
    int session_send_timeout;  //发送超时时间(默认3s)
    int session_max_recv_size; //最大接收缓冲区(默认64K)
    int session_max_send_size; //最大接收缓冲区(默认64K)
    int session_req_per_sec;   //每秒最大请求数(小等于0表示不限制)
};

class ListenConf
{
public:
    string ip;  //监听的地址
    int port;   //监听的端口
    int accept_queue;  //待接收队列大小
    ConfSessionParam session_param;  //会话参数
};

class ConnectConf
{
public:
    string ip;  //连接的地址
    int port;   //连接的端口
    ConfSessionParam session_param;  //会话参数
};

class TCPServerConf
{
public:
    TCPServerConf()
    {
        //server info
        conf_svr_id = 0;
        conf_svr_num = 0;
        conf_svr_index = 0;
        //pack typ
        conf_pack_type = 0;
        //ioserver 最大数量
        conf_max_event_num = 0;
        //listen
        conf_listen_num = 0;
        //connect
        conf_connect_num = 0;
        conf_connect_time = 0;
        conf_connect_ping_time = 0;
    }
    int Init(ConfReader *conf);

    //server info
    int conf_svr_id;
    int conf_svr_num;   //有多少个相同svr_id的svr,各个svr由下面的svr_index来标识
    int conf_svr_index;
    
    //packet类型
    int conf_pack_type;

    //ioserver 最大数量
    int conf_max_event_num;
 
    //listen
    int conf_listen_num;
    vector<ListenConf> conf_listen_list;
    
    //connect
    int conf_connect_num;
    int conf_connect_time;
    int conf_connect_ping_time;
    vector<ConnectConf> conf_connect_list;
private:
    DECL_LOGGER(logger);
};

}//namespace

#endif /* TCPSERVERCONF_H_ */
