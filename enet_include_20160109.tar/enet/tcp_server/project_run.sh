#!/bin/bash

if [ $# -lt 2 ];then
	echo "Usage:project_run.sh THIS_SERVER_IP check|stop|start [SvrName]"
	exit
fi

ip=$1
cmd=$2
SvrName=$3

ConfList=`find ./ -name "*$ip"`
#echo "$ConfList"
ConfList=($ConfList)
for conf in ${ConfList[@]};do
	tmp=${conf#*/}
	Svr=${tmp%%/*}

	if [ "$SvrName" != "" ];then
		if [ "$SvrName" != "$Svr" ];then
			continue
		fi
	fi

	cd $Svr
	./svr_tool.sh $cmd
	cd ../
done
