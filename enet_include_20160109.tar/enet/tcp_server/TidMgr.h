#ifndef _TID_EXPIRE_MGR_H_
#define _TID_EXPIRE_MGR_H_

#include <utility/DateTime.h>
#include <stdint.h>

#include <map>
#include <list>
#include <vector>
using std::map;
using std::list;
using std::vector;

namespace enet
{

//tid-fd超时管理
class TidMgr
{
public:
    //timeout_sec:超时时间(单位秒,0表示不做超时检查)
    int Add(uint64_t tid, void *user_data, uint32_t timeout_sec, uint64_t now_ms=0);  //now=0时由本对象自己添加add_time
    void CheckTimeout(vector<uint64_t> &timeout_tids, uint64_t now_ms=0);  //移除超时的tid(并返回)
    bool IsTimeout(uint64_t tid, uint64_t now_ms=0);  //判断tid是否已经超时
    void RemoveTID(uint64_t tid);  //移除tid
    void RemoveUserData(void *user_data);  //移除对应的所有tid
    void* GetUserData(uint64_t tid);
private:

    typedef struct _fd_info_
    {
        uint64_t tid;
        void* user_data;
        uint64_t expire_ms;
    }FDInfo;
    map<uint64_t/*tid*/, FDInfo> m_TidMap;
    map<void*, list<FDInfo> > m_FdMap;
};

inline
int TidMgr::Add(uint64_t tid, void *user_data, uint32_t timeout_sec, uint64_t now_ms/*=0*/)
{
    //检查tid是否已经存在
    if(m_TidMap.find(tid) != m_TidMap.end())
        return -1;
    //创建tid信息结构
    if(now_ms == 0)
        now_ms = DateTime::NowMS();
    FDInfo fdinfo;
    fdinfo.tid = tid;
    fdinfo.user_data = user_data;
    if(timeout_sec > 0)
    	fdinfo.expire_ms = now_ms+timeout_sec*1000;
    else
    	fdinfo.expire_ms = 0;
    	
    //保存到tid map
    std::pair<map<uint64_t, FDInfo>::iterator, bool> ret = m_TidMap.insert(std::make_pair(tid, fdinfo));
    if(ret.second == false)
        return -3;
    //保存到fd map
    map<void*, list<FDInfo> >::iterator it = m_FdMap.find(user_data);
    if(it == m_FdMap.end())
    {
        list<FDInfo> fdinfo_list;
        fdinfo_list.push_back(fdinfo);
        m_FdMap.insert(std::make_pair(user_data, fdinfo_list));
    }
    else
    {
        it->second.push_back(fdinfo);
    }

    return 0;
}

inline
void TidMgr::CheckTimeout(vector<uint64_t> &timeout_tids, uint64_t now_ms/*=0*/)
{
    if(now_ms == 0)
        now_ms = DateTime::NowMS();

    map<uint64_t, FDInfo>::iterator it;
    for(it=m_TidMap.begin(); it!=m_TidMap.end(); /**/)
    {
        FDInfo &fdinfo = it->second;
        if(fdinfo.expire_ms==0 || fdinfo.expire_ms>now_ms)
        {
            ++it;
            continue;
        }
        //超时
        timeout_tids.push_back(fdinfo.tid);
        //从fd map删除
        map<void*, list<FDInfo> >::iterator fd_it = m_FdMap.find(fdinfo.user_data);
        if(fd_it != m_FdMap.end())
        {
            list<FDInfo> &fdinfo_list = fd_it->second;
            for(list<FDInfo>::iterator list_it=fdinfo_list.begin(); list_it!=fdinfo_list.end(); ++list_it)
            {
                if(list_it->tid != fdinfo.tid)
                    continue;
                fdinfo_list.erase(list_it);
                break;
            }
            if(fdinfo_list.size() == 0)
                m_FdMap.erase(fd_it);
        }
        //从tid map删除
        m_TidMap.erase(it++);  
    }
    return;
}

inline
bool TidMgr::IsTimeout(uint64_t tid, uint64_t now_ms/*=0*/)
{
    if(now_ms == 0)
        now_ms = DateTime::NowMS();
    map<uint64_t, FDInfo>::iterator it = m_TidMap.find(tid);
    if(it == m_TidMap.end())  //不存在(已超时被删除掉)
        return true;
    FDInfo &fdinfo = it->second;
    if(fdinfo.expire_ms>0 && fdinfo.expire_ms<=now_ms)
        return true;
    return false;
}

inline
void TidMgr::RemoveTID(uint64_t tid)
{
    map<uint64_t, FDInfo>::iterator it = m_TidMap.find(tid);
    if(it == m_TidMap.end())  //不存在(已超时被删除掉)
        return ;
    FDInfo &fdinfo = it->second;
    //从fd map删除
    map<void*, list<FDInfo> >::iterator fd_it = m_FdMap.find(fdinfo.user_data);
    if(fd_it != m_FdMap.end())
    {
        list<FDInfo> &fdinfo_list = fd_it->second;
        for(list<FDInfo>::iterator list_it=fdinfo_list.begin(); list_it!=fdinfo_list.end(); ++list_it)
        {
            if(list_it->tid != fdinfo.tid)
                continue;
            fdinfo_list.erase(list_it);
            break;
        }
        if(fdinfo_list.size() == 0)
            m_FdMap.erase(fd_it);
    }
    //从tid map删除
    m_TidMap.erase(it++);  
}

inline
void TidMgr::RemoveUserData(void *user_data)
{
    map<void*, list<FDInfo> >::iterator fd_it = m_FdMap.find(user_data);
    if(fd_it == m_FdMap.end())
        return ;
    list<FDInfo> &fdinfo_list = fd_it->second;
    //删除fd对应所有的tid
    for(list<FDInfo>::iterator list_it=fdinfo_list.begin(); list_it!=fdinfo_list.end(); ++list_it)
        m_TidMap.erase(list_it->tid);
    //删除fd
    m_FdMap.erase(fd_it);
}

inline
void* TidMgr::GetUserData(uint64_t tid)
{
    map<uint64_t, FDInfo>::iterator it = m_TidMap.find(tid);
    if(it == m_TidMap.end())  //不存在(已超时被删除掉)
        return NULL;
    FDInfo &fdinfo = it->second;
    return fdinfo.user_data;
}

} /* namespace */
#endif /* _TID_EXPIRE_MGR_H_ */
