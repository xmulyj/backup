/*
 * ReqHandler.cpp
 *
 *  Created on: Jul 2, 2015
 *      Author: bright
 */

#include "TEMPLATE.h"

#if USE_EXAMPLE == 1
int TEMPLATE::OnExample(TCPSession *session, const char *data, uint32_t head_size, uint32_t body_size, uint64_t tid)
{
    //请求包反序列化
    string req_str;
    req_str.assign(data+head_size, body_size);
    LOG_INFO(logger, "OnExample|Req="<<req_str);

    string rsp_str = "TestExample is ok!";
    char buffer[1024];
    uint32_t rsp_size = 0;

    //回复包序列化
    Packet *packet = GetInternalPacket();
    int header_size = packet->SetHead(buffer, sizeof(buffer), rsp_str.size(), CMD_EXAMPLE_RSP, tid);
    assert(header_size > 0);

    memcpy(buffer+header_size, rsp_str.c_str(), rsp_str.size());
    rsp_size = header_size+rsp_str.size();

    if(session->AsyncSend(buffer, rsp_size) == true)
    {
        LOG_INFO(logger, "OnExample|send OnExampleRsp succ.fd="<<session->GetFD()<<".rsp_size="<<rsp_size);
    }
    else
    {
        LOG_WARN(logger, "OnExample|send OnExampleRsp failed.fd="<<session->GetFD()<<".rsp_size="<<rsp_size);
    }

    return 0;
}
#endif

