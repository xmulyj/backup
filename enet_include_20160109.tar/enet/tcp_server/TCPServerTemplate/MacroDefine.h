/*
 * MacroDefine.h
 *
 *  Created on: Jun 4, 2015
 *      Author: young
 */

#ifndef TCP_SERVER_TCPSERVERTEMPLATE_MACRODEFINE_H_
#define TCP_SERVER_TCPSERVERTEMPLATE_MACRODEFINE_H_

#define USE_EXAMPLE       1
#define USE_ERROR         0
#define USE_LISTEN        0
#define USE_CHECK_TIMER   0
#define USE_CMD_ROUTE     0

#endif /* TCP_SERVER_TCPSERVERTEMPLATE_MACRODEFINE_H_ */
