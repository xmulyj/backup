#!/bin/bash

#svr_tool.sh
#将本脚本放到server的bin目录下,用来检查/启动/停止该server


function check_svr()
{
	SvrName=$1
	r=`ps axu|grep $SvrName|grep -v "grep\|tar\|scp\|log\|project"`
        echo $r
	echo
	if [ "$r" == "" ];then
		return 0
	fi
        cnt=`echo $r|wc -l`
	return $cnt	
}


if [ $# -lt 1 ];then
	echo "usage: ./svr_tool.sh check|start|stop"
	exit
fi


MyPath=`pwd`
#MyPath=${MyPath%/bin}
#echo $MyPath
SvrName=${MyPath##*/}
#echo $SvrName
cd bin



act=$1
if [ "${act}" == "check" ]; then
	check_svr $SvrName
	cnt=$?
	if [ $cnt -eq 0 ];then
		echo "[$SvrName] is not running."
	else
		echo "[$SvrName] is running. Instance Num:$cnt" 
	fi
elif [ "${act}" == "start" ];then
	check_svr $SvrName
	cnt=$?
	if [ $cnt -gt 0 ];then
		echo "[$SvrName] is running alreadly. Instance Num:$cnt"
	else
		nohup ./${SvrName} >nohup.out 2>&1 &
		sleep 1

		check_svr $SvrName
	        cnt=$?
        	if [ $cnt -gt 0 ];then
                	echo "[$SvrName] start successfully. Instance Num:$cnt"
       		else
        	        echo "[$SvrName] start failed."
	        fi
	fi
elif [ "${act}" == "stop" ];then
	killall ${SvrName}
	sleep 1

	check_svr $SvrName
	cnt=$?
	if [ $cnt -gt 0 ];then
                echo "[$SvrName] stop failed. Instance Num:$cnt"
        else
                echo "[$SvrName] stop succ." 
        fi

else
	echo "unknow cmd:$act"
	echo "usage: ./svr_tool.sh check|start|stop"
fi

echo

