#!/bin/bash

if [ $# -lt 1 ];then
	echo "Usage:project_conf.sh THIS_SERVER_IP"
	exit
fi

ip=$1
#echo $ip

ConfList=`find ./ -name "*$ip"`
#echo "$ConfList"

ConfList=($ConfList)

for conf in ${ConfList[@]};do
	tmp=${conf#*/}
	Svr=${tmp%%/*}
	cp $Svr/conf/TCPServer.TEMPLATE $Svr/conf/TCPServer.conf

	#替换@标记的行
	cat $conf|grep '@' > temp.txt
	DST="$Svr/conf/TCPServer.conf"
	SRC="temp.txt"

	while read line ; do 
		TAG=`echo "$line"|awk -F'|' '{print $1}'`; 
		CONTENT=`echo "$line"|awk -F'|' '{print $2}'`; 
		#echo $TAG
		#echo "$CONTENT"
		sed -i "s/^${TAG}.*$/$CONTENT/g" $DST;
	done <temp.txt
	rm temp.txt

	echo -e "$conf\t=>\t$DST"
done
