/*
 * TCPServer.h
 *
 *  Created on: Oct 26, 2014
 *      Author: young
 */

#ifndef TCPSERVER_H_
#define TCPSERVER_H_

#include "Packet.h"
#include "Logger.h"
#include "SessionMgr.h"
#include "IOServer.h"
#include "ConfReader.h"
#include "utility/Utility.h"
#include "TCPServerConf.h"
#include "TidMgr.h"
using namespace enet;

#include <sys/stat.h>
#include <string>
#include <vector>
#include <map>
#include <list>
using std::string;
using std::vector;
using std::map;
using std::list;

namespace enet
{
#define SVR_GROUP_MAX_NUM  100  //与本服务器组有关联的最大服务器组个数(100个肯定是够了)
#define SVR_GROUP_MAX_NODE 100  //每个服务器组里面最多包含的服务器个数(100个应该是够了)

//CMD格式要求:高16位为svr_id,低16位为命令序号
//TCPServer内部使用cmd,应用层请从0x00010000开始
#define CMD_TCP_SERVER_PING 0x00000001              //ping包

class TCPServer;
class TCPSession;

//服务器信息:一个svr_id代表一组相同的服务器组,服务器组里每个服务器用svr_index标识
class ServerInfo
{
public:
    ServerInfo()
        :svr_valid(false)
        ,svr_id(0)
        ,svr_num(0)
        ,svr_index(0)
        ,svr_session(NULL)
        ,svr_pingtime(0)
        ,svr_usecount(0)
    {
    }
    bool     svr_valid;     //本信息是否有效(比如连接断开后就变成无效)
    uint32_t svr_id;        //服务器组id
    uint32_t svr_num;       //该组服务器组有多少个服务器
    uint32_t svr_index;     //该服务器在服务器组中的index
    Session* svr_session;   //服务器之间连接的session
    uint32_t svr_pingtime;  //收到ping包的时间(用来做超时检查)
    uint32_t svr_usecount;  //使用的次数(用来做负载均衡)
};
typedef map<Session*, ServerInfo*> SessionServerMap;  //session找到对应的服务器信息


//连接信息:每各连接对应一个连接信息
class ConnectInfo
{
public:
    SessionMgrDefault<TCPSession> connect_session_mgr;  //连接管理器
    list<TCPSession *> connect_session_list;  //保存已经连接上的session
};

class RouteMgr
{
public:
    //轮询获取session的策略,下标为svr_id,值为下一次获取该服务器组的index;
    //比如m_route_index[3]为2时表示:返回的是svrid=3,index=2的服务器的session;
    //和m_server_group_list配合使用
    vector<uint32_t> m_route_index;
    //服务器组包含多少个服务器
    vector<uint32_t> m_svr_num;
};

//ping包的定时器
class TCPPingTimer: public TimerHandler
{
public:
    void SetServer(TCPServer *server){m_server = server;}
public: //TimerHandler接口
    bool OnTimeOut(uint64_t now_ms);
private:
    TCPServer *m_server;
};


//检查的定时器
class TCPCheckTimer: public TimerHandler
{
public:
    void SetServer(TCPServer *server){m_server = server;}
public: //TimerHandler接口
    bool OnTimeOut(uint64_t now_ms);
private:
    TCPServer *m_server;
};


//TCPSession
class TCPSession:public SessionDefault
{
protected:
    // @override
    bool OnPacket(uint32_t cmd, const char *packet_data, uint32_t head_size, uint32_t body_size, uint64_t tid);
    // @override
    IOStatus OnError(int fd, uint64_t now_ms); //请不要close掉fd,框架会close的.切记切记!!!
};


//TCPServer
class TCPServer
{
friend class TCPPingTimer;
friend class TCPCheckTimer;
friend class TCPSession;
public:
    TCPServer (ConfReader *config)
        :m_conf_reader(config)
        ,m_internal_packet(NULL)
    {
        m_server_group_list.resize(SVR_GROUP_MAX_NUM);

        m_route_mgr.m_route_index.resize(SVR_GROUP_MAX_NUM, 0);
        m_route_mgr.m_svr_num.resize(SVR_GROUP_MAX_NUM, 0);
    }
    virtual ~TCPServer(){}
    
    int Init();
    int RunForever();

    // 获取TCPServer配置
    const TCPServerConf& GetTCPServerConf(){return m_conf;}

    // 获取IOServer
    IOServer* GetIOServer(){return &m_io_server;}

    // 服务器之间使用的打包器,默认使用静态Packet类
    void SetInternalPacket(Packet *packet){m_internal_packet = packet;}
    Packet* GetInternalPacket(){return m_internal_packet;}

    // 根据命令号返回对应svr的session
    Session* ServerGroup_GetSession(uint32_t cmd);  //轮巡路由
    Session* ServerGroup_GetSession(uint32_t cmd, uint32_t route_key);  //按route_key对改组服务器个数取模路由
    // 取指定server的某个session
    Session* ServerGroup_GetSessionExt(uint32_t svr_id, uint32_t svr_index);

    // 保存/获取事务对应的session
    int SaveTraction(uint64_t tid, Session *session, uint32_t timeout);
    Session* GetTraction(uint64_t tid, bool rm_tid=true);
    void DelTraction(uint64_t tid);

    // 初始化SessonMgr
    void InitSessionMgr(SessionMgr *session_mgr, const ConfSessionParam &session_param);

    // 判断cmd是否有注册对应的hander
    virtual bool HaveHandler(uint32_t cmd){return HAS_HANDLE(cmd);}
//子类根据需要实现的接口
protected:
    // 具体子类的初始化方法
    virtual int OnInit(ConfReader *config)
    {
        return 0;
    }

    // @override BinaryIOHandler
    ////virtual bool OnPacket(int fd, uint32_t cmd, const char *packet_data, uint32_t head_size, uint32_t body_size);
    // 使用session后定义这个
    // 子类重写本方法后需要在里面对没有注册的cmd调用本方法,让父类来处理 !!!
    //virtual bool OnPacket(int fd, uint32_t cmd, const char *packet_data, uint32_t head_size, uint32_t body_size);
    virtual bool OnPacket(TCPSession *session, uint32_t cmd, const char *packet_data, uint32_t head_size, uint32_t body_size, uint64_t tid)
    {
        LOG_TRACE(logger, "OnPacket:cmd="<<cmd<<",head_size="<<head_size<<",body_size="<<body_size<<",tid="<<tid<<".fd="<<session->GetFD());
        if(!HAS_HANDLE(cmd))
        {
            LOG_ERROR(logger, "OnPacket:not find handler for cmd="<<cmd<<".fd="<<session->GetFD());
            return false;
        }
        HANDLER_TYPE handler = GET_HANDLE(cmd);
        int ret = (this->*handler)(session, packet_data, head_size, body_size, tid);
        return ret==0?true:false;
    }

    // 会话结束调用,回收相关资源
    virtual IOStatus OnError(TCPSession *session, uint64_t now_ms)
    {
        LOG_ERROR(logger, "OnError:fd="<<session->GetFD());
        ServerGroup_Del(session);
        return IO_SUCC;
    }

    // 创建listen成功后调用,需要处理listen_fd的连接事件
    virtual bool OnListenSucc(uint32_t index, uint32_t listen_fd, const ConfSessionParam &session_param)
    {
        LOG_DEBUG(logger, "OnListenSucc|index="<<index);
        switch(index)
        {
        case 0:
            InitSessionMgr(&m_listen_session_mgr, session_param);
            m_listen_session_mgr.Init(GetIOServer(), GetInternalPacket(), listen_fd);
            break;
    //        case 1:
    //            InitSessionMgr(&m_listen_session_mgr_1, session_param);  //初始化listen session mgr
    //            m_listen_session_mgr_0.Init(GetIOServer(), m_packet_1, listen_fd);
    //            break;
        default:
            return false;
        }

        return true;
    }

    // 每秒定时器触发
    virtual void OnCheckPerSec(uint64_t now_ms)
    {
    }

    // 根据cmd获取服务器组中的一个session(默认返回第一个有效的session).子类可以根据自己的路由规则需求重写本方法
    virtual Session* SererGroup_GetSession(uint32_t cmd, uint32_t svr_id, vector<ServerInfo>&svr_group)
    {
        if(svr_group.size()>0 && svr_group[0].svr_valid)
        {
            LOG_DEBUG(logger, "TCPServer|SererGroup_GetSession|use first svr_info by default.cmd="<<cmd
                        <<",svr_id="<<svr_group[0].svr_id
                        <<",svr_num="<<svr_group[0].svr_num
                        <<",svr_inde="<<svr_group[0].svr_index
                        <<",svr_session"<<svr_group[0].svr_session);
            return svr_group[0].svr_session;
        }

        LOG_ERROR(logger, "TCPServer|SererGroup_GetSession|no valid session.cmd="<<cmd
                        <<",svr_id="<<svr_id
                        <<",svr_group size="<<svr_group.size());
        return NULL;
    }

private:
    // 创建监听
    int DoListen();

    // 创建连接
    int DoConnect();
    int DoConnect(ConnectInfo &connect_info, const ConnectConf &connnect_conf);

    //发送/接收ping包
    bool DoPing();

    //1s定时检查
    bool DoCheckPerSec(uint64_t now_ms);
private:
    ConfReader*       m_conf_reader;
    TCPServerConf     m_conf;             //TCPServer配置

    Packet*           m_internal_packet;  //内部服务器直接使用的打包器
    IOServerEpoll     m_io_server;        //IOServer

    TCPPingTimer      m_ping_timer;       //发送ping包定时器
    TCPCheckTimer     m_check_timer;      //检查定时器

    SessionMgrDefault<TCPSession> m_listen_session_mgr;  //内部使用的监听fd接收的session管理器
    vector<ConnectInfo> m_connect_vec;    //连接的信息列表

    //服务器列表(每个元素对应一个服务器组,该服务器组svr_id作为下标,初始化100个服务器组的大小,100个服务器组应该够了把)
    vector<vector<ServerInfo> > m_server_group_list;  //ServerInfo映射到session

    //轮询路由管理
    RouteMgr m_route_mgr;


    SessionServerMap m_session_server_map;  //会话映射到ServerInfo
    bool ServerGroup_Add(ServerInfo &server_info);  //收到ping包时添加发送该ping包的svr信息
    void ServerGroup_Del(TCPSession *session);  //删除会话

    //tid管理器
    TidMgr m_tid_mgr;
private:
    DECL_LOGGER(logger);

//设置cmd对应的handler
private:
    // CmdID的处理方法类型定义
    //   session: 请求的会话信息(即代表一个连接)
    //      data: 完整的请求数据,包含协议头和协议体;协议头主要用来分包的,协议体则包含应用层自定义的协议数据(参考Packet类的定义)
    // head_size: 协议头长度
    // body_size: 协议头体长度
    //       tid: 事务id(代表每个请求的唯一id号)
    // handler类型定义
    typedef int (Handler)(TCPSession *session, const char *data, uint32_t head_size, uint32_t body_size, uint64_t tid);
    // handler指针类型定义
    typedef int (TCPServer::*HANDLER_TYPE)(TCPSession *session, const char *data, uint32_t head_size, uint32_t body_size, uint64_t tid);
    //声明handler方法
    Handler OnPing;  //处理ping包

    HANDLE_REG(TCPServer, uint32_t, HANDLER_TYPE)
    HANDLE_CMD(CMD_TCP_SERVER_PING, OnPing)
    HANDLE_REG_END
};


///////////// 实现 /////////////
//ping包发送定时器
inline
bool TCPPingTimer::OnTimeOut(uint64_t now_ms)
{
    return m_server->DoPing();
}

//定时任务检查定时器
inline
bool TCPCheckTimer::OnTimeOut(uint64_t now_ms)
{
    return m_server->DoCheckPerSec(now_ms);
}

//TCPSession
inline
bool TCPSession::OnPacket(uint32_t cmd, const char *packet_data, uint32_t head_size, uint32_t body_size, uint64_t tid)
{
    TCPServer* tcp_server = (TCPServer*)GetUserData();
    assert(tcp_server != NULL);
    return tcp_server->OnPacket(this, cmd, packet_data, head_size, body_size, tid);
}

inline
IOStatus TCPSession::OnError(int fd, uint64_t now_ms)
{
    TCPServer* tcp_server = (TCPServer*)GetUserData();
    assert(tcp_server != NULL);
    tcp_server->OnError(this, now_ms);
    return SessionDefault::OnError(fd, now_ms);
}

//TCPServer
inline
void TCPServer::InitSessionMgr(SessionMgr *session_mgr, const ConfSessionParam &session_param)
{
    //初始化session mgr的参数
    session_mgr->SetMaxSession(session_param.session_max_num);         //最大连接数
    session_mgr->SetBlockMode(session_param.session_block);            //阻塞模式
    session_mgr->SetIdleTime(session_param.session_idle_time);    //空闲超时时间
    session_mgr->SetRecvTime(session_param.session_recv_timeout);      //接收超时时间
    session_mgr->SetSendTime(session_param.session_send_timeout);      //发送超时时间
    session_mgr->SetMaxRecvSize(session_param.session_max_recv_size);  //最多接收缓冲区
    session_mgr->SetMaxSendSize(session_param.session_max_send_size);  //最大发送缓冲区
    session_mgr->SetMaxReqPerSec(session_param.session_req_per_sec);   //每秒最大请求个数
    session_mgr->SetUserData((void*)this);                             //用户数据
}

inline
int TCPServer::SaveTraction(uint64_t tid, Session *session, uint32_t timeout_sec)
{
    return m_tid_mgr.Add(tid, session, timeout_sec);
}

inline
Session* TCPServer::GetTraction(uint64_t tid, bool rm_tid)
{
    if(m_tid_mgr.IsTimeout(tid))
    {
        m_tid_mgr.RemoveTID(tid);
        return NULL;
    }
    void *user_data = m_tid_mgr.GetUserData(tid);
    if(user_data!=NULL && rm_tid==true)
    {
        m_tid_mgr.RemoveTID(tid);
    }
    return static_cast<Session*>(user_data);
}
inline
void TCPServer::DelTraction(uint64_t tid)
{
    m_tid_mgr.RemoveTID(tid);
}

}//namespace

#endif /* TCPSERVER_H_ */

