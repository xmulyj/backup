/*
 * IOServer.h
 *
 *  Created on: 2014-7-14
 *      Author: yongjinliu
 */

#ifndef IOSERVER_H_
#define IOSERVER_H_
#include <assert.h>
#include <sys/select.h>
#include <errno.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/time.h>
#include <unistd.h>

#include <map>
#include <vector>

#include "IOContext.h"
#include "WheelTimer.h"
#include "ByteBuffer.h"
#include "Logger.h"

namespace enet
{
#define TIME_INFINITY -1


#define GetCurTime(now) do{              \
    struct timeval tv;                    \
    gettimeofday(&tv, NULL);              \
    now = tv.tv_sec*1000+tv.tv_usec/1000; \
}while(0)

/////////////////////////////////////////////////////////////////////////////////////////
//io事件
typedef uint16_t IOEvent;
#define EVENT_EMPTY    0x0000                    //空
#define EVENT_READ     0x0001                    //读
#define EVENT_WRITE    0x0002                    //写
#define EVENT_RDWT     0x0003                    //读写
#define EVENT_ERROR    0x0004                    //错误

#define EVENT_HAS_READ(x)  (((x)&EVENT_READ)  != 0) //是否设置读
#define EVENT_HAS_WRITE(x) (((x)&EVENT_WRITE) != 0) //是否设置写
#define EVENT_HAS_ERROR(x) (((x)&EVENT_ERROR) != 0) //是否发生错误

/////////////////////////////////////////////////////////////////////////////////////////
typedef enum _io_status_
{
    IO_ERROR,
    IO_CONTINUE,
    IO_SUCC,
}IOStatus;

class IOServer;
class IOHandler
{
public:
    IOHandler()
            :m_io_server(NULL)
            ,m_idle_time(3000)
            ,m_IOContextMgr(3000)
    {

    }

    //idle_ms:空闲时间(毫秒)
    //persist:持续性处理事件(事件发生后不会删除监听的事件)
    IOHandler(IOServer *io_server, int idle_ms)
            :m_io_server(io_server)
            ,m_idle_time(idle_ms)
            ,m_IOContextMgr(idle_ms)
    {
        assert(m_io_server != NULL);
    }

    virtual ~IOHandler()
    {
    }

    virtual void Init(IOServer *io_server, int idle_ms)
    {
        m_io_server = io_server;
        m_idle_time = idle_ms;
        m_IOContextMgr.Init(idle_ms);
        assert(m_io_server != NULL);
    }

    IOServer* GetIOServer()
    {
        return m_io_server;
    }

    void SetIdleTime(int idle_time){m_idle_time = idle_time;}
    int GetIdleTime(){return m_idle_time;}
public:
    virtual IOStatus OnRead(int fd, uint64_t now_ms)=0;
    virtual IOStatus OnWrite(int fd, uint64_t now_ms)=0;
    virtual IOStatus OnError(int fd, uint64_t now_ms)=0;  //请不要close掉fd,框架会close的.切记切记!!!
private:
    IOServer *m_io_server;
    int m_idle_time;  //毫秒
protected:
    IOContextMgr m_IOContextMgr;
};


class TimerHandler: public IOHandler
{
public:
    TimerHandler()
        :m_is_persist(false)
    {
    }

    TimerHandler(IOServer *io_server, int idle_ms, bool persist)
        :IOHandler(io_server, idle_ms)
        ,m_is_persist(persist)
    {
        assert(idle_ms > 0);
    }

    virtual void Init(IOServer *io_server, int idle_ms, bool persist)
    {
        assert(idle_ms > 0);
        IOHandler::Init(io_server, idle_ms);
        m_is_persist = persist;
    }

    IOStatus OnRead(int fd, uint64_t now_ms){assert(0); return IO_SUCC;}
    IOStatus OnWrite(int fd, uint64_t now_ms){assert(0); return IO_SUCC;}
    IOStatus OnError(int fd, uint64_t now_ms){return OnTimeOut(now_ms)?IO_SUCC:IO_ERROR;}
public:
    bool IsPersist(){return m_is_persist;}
    virtual bool OnTimeOut(uint64_t now_ms){return true;}
private:
    bool m_is_persist;
};

class IdleProcess
{
public:
    virtual ~IdleProcess(){}
    virtual void OnIdle() = 0;
    virtual bool NeedProcess()=0;
};

class IOServer
{
private:
    class IOEventInfo
    {
    public:
        IOEventInfo()
            :fd(-1)
            ,timer_id(NULL)
            ,event(EVENT_EMPTY)
            ,handler(NULL)
        {}

        int fd;
        TimerID timer_id;
        IOEvent event;
        IOHandler *handler;
    };
    std::map<int, IOEventInfo> m_FDMap;
public:
    class EventOccur
    {
    public:
        int fd;
        IOEvent event;
        EventOccur():fd(-1),event(EVENT_EMPTY){}
    };

public:
    IOServer():m_has_stop(false),m_idle_process(NULL){}
    virtual ~IOServer(){}
    bool RunOnce();
    bool RunForever();
    void Stop(){m_has_stop = true;}

    void SetIdleProcess(IdleProcess *idle_process){m_idle_process = idle_process;}

    //添加事件,成功返回pair:first表示添加之后的event(EVENT_EMPTY表示失败),second表示添加之前的event
    virtual std::pair<IOEvent,IOEvent> AddEvent(int fd, IOEvent event, IOHandler *handler);
    //删除时间,成功返回pair:first表示删除之后的event,second表示删除之前的event
    virtual std::pair<IOEvent,IOEvent> DelEvent(int fd, IOEvent event);
    //添加定时器,成功返回true,失败false
    virtual bool AddTimer(TimerHandler *handler);
    //等待事件的发生
    virtual bool WaitEvent(std::vector<EventOccur> &event_occurs, int wait_ms)=0;

    //同步等待time_ms毫秒
    static void Wait(int time_ms);
    //同步等待time_ms毫秒,然后带哦也timer
    static void Wait(TimerHandler *timer);
    //同步等待time_ms毫秒,然后调用回调函数
    static void Wait(int time_ms, void (*OnTimeOut)(void *), void *user_data);
protected:
    WheelTimer  m_Timer;
    IOEvent CurEvent(int fd);
private:
    bool m_has_stop;
    IdleProcess *m_idle_process;
private:
    DECL_LOGGER(logger);
};

inline
bool IOServer::RunForever()
{
    while(true)
    {
        if(m_has_stop)
            break;
        if(!RunOnce())
            break;
    }
    return true;
}

#define IO_WAIT_TIME(time_ms) do{\
    struct timeval tv; \
    tv.tv_sec=time_ms/1000; \
    tv.tv_usec=(time_ms%1000)*1000; \
    int err; \
    do{ \
       err = select(0,NULL,NULL,NULL,&tv); \
    }while(err<0 && errno==EINTR); \
}while(0)

inline
void IOServer::Wait(int time_ms)
{
    IO_WAIT_TIME(time_ms);
}

inline
void IOServer::Wait(TimerHandler *timer)
{
    assert(timer != NULL);
    int time_ms = timer->GetIdleTime();
    IO_WAIT_TIME(time_ms);
    timer->OnTimeOut(0);
}

inline
void IOServer::Wait(int time_ms, void (*OnTimeOut)(void *), void *user_data)
{
    assert(OnTimeOut != NULL);
    IO_WAIT_TIME(time_ms);
    OnTimeOut(user_data);
}


class IOServerEpoll:public IOServer
{
public:
    IOServerEpoll();
    IOServerEpoll(uint32_t max_events);
    ~IOServerEpoll();

    void Init(uint32_t max_events);

    std::pair<IOEvent,IOEvent> AddEvent(int fd, IOEvent event, IOHandler *handler);
    std::pair<IOEvent,IOEvent> DelEvent(int fd, IOEvent event);
    bool WaitEvent(std::vector<EventOccur> &event_occurs, int wait_ms);
private:
    int m_EpFd;
    uint32_t m_MaxEvents;
    struct epoll_event* m_EventData;
private:
    DECL_LOGGER(logger);
};

}//namespace
#endif /* IOSERVER_H_ */
