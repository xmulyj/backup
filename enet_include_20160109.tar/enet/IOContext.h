/*
 * IOContextMgr.h
 *
 *  Created on: 2014-7-21
 *      Author: yongjinliu
 */

#ifndef IOCONTEXT_H_
#define IOCONTEXT_H_
#include <stdint.h>
#include <map>

#include "ByteBuffer.h"
#include "Logger.h"

namespace enet
{

class IOContext
{
public:
    int fd;
    uint32_t size;       //发送数据时,框架将该字段当作已经发送的字节数;
    union
    {
        void *ptr;
        uint32_t value32;
        uint64_t value64;
    }user_data;     //用户数据

    uint64_t expire_time;
    ByteBuffer byte_buffer;

    IOContext()
    {
        fd = -1;
        expire_time = 0;
        size = 0;
        user_data.value64 = 0;
    }
};

class IOContextMgr
{
public:
    IOContextMgr()
        :m_idle_time(3000)
    {
    }

    IOContextMgr(int idle_time_ms)
        :m_idle_time(idle_time_ms)
    {
    }

    ~IOContextMgr()
    {
        m_recv_map.clear();
        m_send_map.clear();
    }

    void Init(int idle_time_ms)
    {
        m_idle_time = idle_time_ms;
    }

    //接收数据包(可能包含多个包的数据),返回context(该context由框架管理),失败返回NULL;
    IOContext* RecvData(int fd, uint64_t now_ms);
    //发送框架里面的数据,返回剩余数据(0已经发送完成,-1错误)
    int SendData(int fd, uint64_t now_ms);

    //是否有待发送的数据包
    bool HaveWaitToSend(int fd, uint64_t now_ms);
    //获取发送的context,返回NULL表示超时或者内存不够
    IOContext* GetSendConxt(int fd, uint64_t now_ms);

    //删除和fd相关的context
    void DeleteContext(int fd);

    //////////////// 与接收数据相关的方法 ////////////////
    //接收数据包(可能包含多个包的数据)到byte_buffer中,成功返回true,失败返回false;
    static bool RecvData(int fd, ByteBuffer &byte_buffer);
    //从io_context中弹出一个大小为packet_size的数据包,成功返回包大小,0表示没有包;
    //如果byte_buffer非空,则byte_buffer保留弹出的数据包;
    static uint32_t PopPacket(IOContext &io_context, uint32_t packet_size, ByteBuffer *byte_buffer=NULL);

    //////////////// 与发送数据相关的方法 ////////////////
    //返回剩下的字节数,0表示全部发送,-1表示错误;
    static int SendData(int fd, ByteBuffer &byte_buffer, uint32_t begin=0);
private:
    std::map<int, IOContext> m_recv_map;
    std::map<int, IOContext> m_send_map;

    int m_idle_time; //毫秒
    //进行了超时检查
    IOContext* GetContext(std::map<int, IOContext> &context_map, int fd, uint64_t now_ms);
private:
    DECL_LOGGER(logger);
};

}//namespace
#endif /* IOCONTEXT_H_ */
