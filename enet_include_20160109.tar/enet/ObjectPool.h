/*
 * ObjectPool.h
 *
 *  Created on: 2014-7-30
 *      Author: yongjinliu
 */

#ifndef OBJECTPOOL_H_
#define OBJECTPOOL_H_

#include <assert.h>
#include <stdlib.h>
#include <string.h>

namespace enet
{

//简单的对象池.适合struct类型使用
template <class T>
class ObjectPool
{
public:
    ObjectPool();
    ~ObjectPool();

    T* Get();
    void Put(T *node);
private:
    int m_NumEachBlock;
    int m_CurBlock;
    int m_TotalBlock;
    T *m_FreeList;

    typedef struct _node_block_
    {
        int index;
        void *element_array;
    }NodeBlock;
    NodeBlock *m_NodeBlockArray;
};

template<class T>
ObjectPool<T>::ObjectPool()
    :m_NumEachBlock(100)
    ,m_CurBlock(0)
    ,m_TotalBlock(64)
    ,m_FreeList(NULL)
{
    m_NodeBlockArray = (NodeBlock*)malloc(m_TotalBlock*sizeof(NodeBlock));
    assert(m_NodeBlockArray != NULL);
    memset(m_NodeBlockArray, 0, m_TotalBlock*sizeof(NodeBlock));
    m_NodeBlockArray[m_CurBlock].index = 0;
    m_NodeBlockArray[m_CurBlock].element_array = (T*)malloc(m_NumEachBlock*sizeof(T));
    assert(m_NodeBlockArray[m_CurBlock].element_array != NULL);
}

template<class T>
ObjectPool<T>::~ObjectPool()
{
    for(int i=0; i<m_TotalBlock; ++i)
    {
        if(m_NodeBlockArray[i].element_array == NULL)
            break;
        free(m_NodeBlockArray[i].element_array);
    }
    free(m_NodeBlockArray);
}

template<class T>
T* ObjectPool<T>::Get()
{
    T *node = NULL;
    if(m_FreeList != NULL)
    {
        node = m_FreeList;
        m_FreeList = m_FreeList->next;
    }
    else
    {
        if(m_NodeBlockArray[m_CurBlock].index >= m_NumEachBlock)
        {
            ++m_CurBlock;
            if(m_CurBlock >= m_TotalBlock)
            {
                m_TotalBlock *= 2;
                m_NodeBlockArray = (NodeBlock*)realloc(m_NodeBlockArray, m_TotalBlock*sizeof(NodeBlock));
                assert(m_NodeBlockArray != NULL);
            };

            m_NodeBlockArray[m_CurBlock].index = 0;
            m_NodeBlockArray[m_CurBlock].element_array = malloc(m_NumEachBlock*sizeof(T));
            assert(m_NodeBlockArray[m_CurBlock].element_array != NULL);
        }

        node = ((T*)m_NodeBlockArray[m_CurBlock].element_array)+m_NodeBlockArray[m_CurBlock].index;
        ++m_NodeBlockArray[m_CurBlock].index;
    }

    return node;
}

template<class T>
void ObjectPool<T>::Put(T *node)
{
    assert(node != NULL);
    node->next = m_FreeList;
    m_FreeList = node;
}

}//namespace

#endif /* OBJECTPOOL_H_ */
