/*
 * HttpTool.h
 *
 *  Created on: 2014-7-23
 *      Author: yongjinliu
 */

#ifndef HTTPTOOL_H_
#define HTTPTOOL_H_
#include <stdint.h>

namespace enet
{

typedef enum _http_method_
{
    HTTP_METHOD_INVALID = 0,
    HTTP_METHOD_GET = 1,
    HTTP_METHOD_POST = 2,
}HttpMethod;


typedef struct _http_req_
{
    HttpMethod method;
    int version;  //10:1.0; 11:1.1
    uint32_t head_size;
    const char *url;
    uint32_t url_size;
    const char *param;  //get参数
    uint32_t param_size;
    const char *post;   //post参数
    uint32_t post_size;
}HttpReq;

extern int *MethodLen;
class HttpTool
{
public:
    static HttpMethod GetMethod(const char *method);
    static bool ParseHeadLine(HttpReq &req, const char *data, int head_size);
    static int GetUrlSize(const char *url, int max_size);
    static int GetParamSize(const char *param, int max_size);
    //查找pattern在data中的位置,没有返回-1;
    static int Find(const char *data, int size, const char *pattern, bool i=false); //i:是否忽略大小写
};

inline
HttpMethod HttpTool::GetMethod(const char *method)
{
    if(method[0]=='G' && method[1]=='E' && method[2]=='T' && method[3]==' ')
        return HTTP_METHOD_GET;
    if(method[0]=='P' && method[1]=='O' && method[2]=='S' && method[3]=='T' && method[4]==' ')
        return HTTP_METHOD_POST;
    return HTTP_METHOD_INVALID;
}

inline
int HttpTool::GetUrlSize(const char *url, int max_size)
{
    const char *temp=url, *END=url+max_size;
    for(;temp<END; ++temp)
        if(*temp=='?' || *temp==' ')
            return temp-url;
    return -1;
}

inline
int HttpTool::GetParamSize(const char *param, int max_size)
{
    const char *temp=param, *END=param+max_size;
    for(;temp<END; ++temp)
        if(*temp == ' ')
            return temp-param;
    return -1;
}

}//namespace
#endif /* HTTPTOOL_H_ */
