/*
 * FileData.h
 *
 *  Created on: 2014-12-23
 *      Author: yongjinliu
 */
#ifndef _FILE_DATA_H_
#define _FILE_DATA_H_

#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <stdint.h>

namespace enet
{

class FileData
{
public:
    FileData()
        :m_data(NULL)
        ,m_size(0)
    {
    }

    ~FileData()
    {
        if(m_data != NULL)
            free(m_data);
        m_data = NULL;
        m_size = 0;
    }

    static int FileSize(const char *file_name)
    {
        if(file_name==NULL || file_name[0]=='\0')
        {
            return -1;
        }

        struct stat stat_buf;
        if(stat(file_name, &stat_buf) == -1)
        {
            return -2;
        }
        
        return stat_buf.st_size;
    }

    int Read(const char *file_name)
    {
        if(file_name==NULL || file_name[0]=='\0')
        {
            return -1;
        }

        struct stat stat_buf;
        if(stat(file_name, &stat_buf) == -1)
        {
            return -2;
        }

        FILE *fp = fopen(file_name, "rb");
        if(fp == NULL)
        {
            return -3;
        }

        char *buffer = (char*)malloc(stat_buf.st_size+1);
        if(buffer == NULL)
        {
            fclose(fp);
            return -4;
        }

        size_t read_size = fread(buffer, 1, stat_buf.st_size, fp);
        if(read_size != stat_buf.st_size)
        {
            free(buffer);
            fclose(fp);
            return -5;
        }
        buffer[stat_buf.st_size] = '\0';
        fclose(fp);


        m_data = buffer;
        m_size = stat_buf.st_size;
        return 0;
    }

    char* Data(){return m_data;}
    unsigned int Size(){return m_size;}
private:
    char *m_data;
    unsigned int m_size;
};

} /* namespace */

#endif /* _FILE_DATE_H_ */
