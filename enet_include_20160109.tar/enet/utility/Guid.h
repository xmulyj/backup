/*
 * Guid.h
 *
 *  Created on: Oct 2, 2014
 *      Author: young
 */

#ifndef GUID_H_
#define GUID_H_

#include "DateTime.h"
#include <stdio.h>

namespace enet
{

//根据时间戳+计数+id来产生64位的guid
//秒占32~63位;毫秒占22~31位;count占10~21位;id占0~9位
//相当于1ms最多4096个计数,最多有1024个不同的id

//优化:
//  当count=0的时候保存一次当前时间戳;下次取guid的时候直接增加count来生成guid;
//  当count重新变成0的时候再设置一次时间戳,这样可以避免频繁调用系统函数获取时间;
class GUID
{
public:
    static uint64_t Get(uint32_t id=0);
    static uint32_t ID(uint64_t tid);
    static const char* StrInfo(uint64_t guid);
};

inline
uint64_t GUID::Get(uint32_t id)
{
    static uint32_t count = 0;
    static time_t sec;
    static uint32_t ms;
    
    count &= 0xFFF;
    if(count == 0)
        DateTime::NowMS(sec, ms);
    uint64_t guid = (sec<<32)+(ms<<22)+(count<<10)+(id&0x3F);
    ++count;

    return guid;
}

inline
uint32_t GUID::ID(uint64_t tid)
{
    return (tid&0x3F);
}

inline
const char* GUID::StrInfo(uint64_t guid)
{
    static char buffer[100];
    sprintf(buffer, "t=%lu.%d,c=%d,id=%d", guid>>32, (uint32_t)(guid>>22)&0x3FF,(uint32_t)(guid>>10)&0xFFF, (uint32_t)guid&0x3F);
    return buffer;
}

}//namespace


#if 0
#include "Guid.h"
#include <stdio.h>
#include <stdint.h>
int main()
{
    for(int i=0; i<100; ++i)
    {
        uint64_t guid = enet::GUID::Get();
        printf("%lu\n", guid);

        printf("%s\n", enet::GUID::StrInfo(guid));
    }
    return 0;
}

#endif

#endif /* GUID_H_ */
