/*
 * DateTime.h
 *
 *  Created on: Oct 2, 2014
 *      Author: young
 */

#ifndef DATETIME_H_
#define DATETIME_H_

#include <time.h>
#include <sys/time.h>
#include <stdint.h>
#include <stddef.h>

namespace enet
{

class DateTime
{
public:
    static uint64_t NowMS();  //当前时间(ms)
    static uint64_t NowUS();  //当前时间(us)
    static void NowMS(time_t &sec, uint32_t &ms);  //当前秒和毫秒
    static time_t NowSEC(); //当前秒
    
    static time_t BeginOfDay();
    static time_t BeginOfDay(time_t t);
    
    static time_t EndOfDay();
    static time_t EndOfDay(time_t t);
};

inline
uint64_t DateTime::NowMS()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);

    uint64_t now = tv.tv_sec*1000;
    now += tv.tv_usec/1000;
    return now;
}

inline
uint64_t DateTime::NowUS()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);

    uint64_t now = tv.tv_sec;
    now = now*1000000 + tv.tv_usec;
    return now;
}

inline
void DateTime::NowMS(time_t &sec, uint32_t &ms)  //当前秒和毫秒
{
    struct timeval tv;
    gettimeofday(&tv, NULL);

    sec = tv.tv_sec;
    ms = tv.tv_usec/1000;
}

inline
time_t DateTime::NowSEC()
{
    return time(NULL);
}

inline
time_t DateTime::BeginOfDay()
{
        time_t now = time(NULL);
        struct tm *tmval = localtime(&now);
        tmval->tm_hour = 0;
        tmval->tm_min = 0;
        tmval->tm_sec = 0;
        time_t begin = mktime(tmval);
        return begin;
}

inline
time_t DateTime::BeginOfDay(time_t t)
{
        struct tm *tmval = localtime(&t);
        tmval->tm_hour = 0;
        tmval->tm_min = 0;
        tmval->tm_sec = 0;
        time_t begin = mktime(tmval);
        return begin;
}

inline
time_t DateTime::EndOfDay()
{
        time_t now = time(NULL);
        struct tm *tmval = localtime(&now);
        tmval->tm_hour = 23;
        tmval->tm_min = 59;
        tmval->tm_sec = 59;
        time_t begin = mktime(tmval);
        return begin;
}

inline
time_t DateTime::EndOfDay(time_t t)
{
        struct tm *tmval = localtime(&t);
        tmval->tm_hour = 23;
        tmval->tm_min = 59;
        tmval->tm_sec = 59;
        time_t begin = mktime(tmval);
        return begin;
}

}//namespace
#endif /* DATETIME_H_ */
