/*
 * Utility.h
 *
 *  Created on: Oct 31, 2014
 *      Author: young
 */

#ifndef UTILITY_H_
#define UTILITY_H_

#include <assert.h>
#include <stdio.h>
#include <ctype.h>
#include <map>
using std::map;

namespace enet
{

/*
当一个类里面需要根据某个值来选择对应的成员方法做对应的事情时(这些成员方法的参数类型,返回值都一样),如果不希望用
if..else if...else if...else或者switch..case..case..default这类方式来处理时,可以考虑使用下面的宏定义来解决.
*/
/*
#define DEF_HANDLE(KEY, FUNC_TYPE) map<KEY, FUNC_TYPE> m_handler_map
#define HAS_HANDLE(KEY) (m_handler_map.find(KEY)!=m_handler_map.end())
#define GET_HANDLE(KEY) (m_handler_map[cmd])
#define HANDLE_CLASS(CLASS_NAME) typedef class CLASS_NAME T; do{
#define HANDLE_CMD(cmd, handler) assert(!HAS_HANDLE(cmd)); m_handler_map.insert(std::make_pair(cmd, &T::handler));
#define HANDLE_CLASS_END }while(0);
*/

#define HAS_HANDLE(KEY) (__handler_map__.find(KEY) != __handler_map__.end())
#define GET_HANDLE(KEY) (__handler_map__[cmd])

#define HANDLE_REG(CLASS_NAME, KEY, HANDLER_TYPE) map<KEY, HANDLER_TYPE> __handler_map__; void __CmdReg__(){typedef class CLASS_NAME T;do{
#define HANDLE_CMD(cmd, handler) assert(!HAS_HANDLE(cmd)); __handler_map__.insert(std::make_pair(cmd, &T::handler));
#define HANDLE_REG_END }while(0);}
#define CALL_HANDLE_REG() __CmdReg__()

#define DEF_HANDLER_BEGIN
#define DEF_HANDLER_END

/* example
class Base
{
public:
    virtual ~Base(){}
    int base(int i){return i+0;}
    virtual int OnData(int cmd, int data)=0;
};
class Drive:public Base
{
public:
    typedef int (Drive::*HANLDER_TYPE)(int i);  //定义类成员指针类型
    int a(int i){return i+1;}
    int b(int i){return i+2;}
    int c(int i){return i+3;}
    int init();
    int OnData(int cmd, int data)
    {
        if(!HAS_HANDLE(cmd))
            return -1;
        HANLDER_TYPE ptr = GET_HANDLE(cmd);
        return (this->*ptr)(data);
    }
private:
    DEF_HANDLE(int, HANLDER_TYPE); //定义一个handler的实例
};
inline
int Drive::init()
{
    HANDLE_CLASS(Drive) //声明使用的是Drive这个类
    HANDLE_CMD(0, base) //用base方法处理0对应的事(这个是父类的方法!!!)
    HANDLE_CMD(1, a) //用a方法处理1对应的事
    HANDLE_CMD(2, b)
    HANDLE_CMD(3, c)
    HANDLE_CLASS_END //结束
    return 0;
}
int main()
{
    Drive a;
    a.init();
    int result;
    result = a.OnData(0, 10); printf("ret=%d\n", result);
    result = a.OnData(1, 10); printf("ret=%d\n", result);
    result = a.OnData(2, 10); printf("ret=%d\n", result);
    result = a.OnData(3, 10); printf("ret=%d\n", result);
}
*/

static char* ToString(const char *buff, uint32_t size)
{
    char *out = (char*)malloc(size+1);
    uint32_t j=0;
    for(uint32_t i=0; i<size; ++i)
    {
        if(isprint(buff[i]))
            out[j++] = buff[i];
    }
    out[j] = '\0';
    return out;
}

}
#endif /* UTILITY_H_ */
