/*
 * HttpIOHandler.h
 *
 *  Created on: 2014-7-23
 *      Author: yongjinliu
 */

#ifndef HTTP_IOHANDLER_H_
#define HTTP_IOHANDLER_H_

#include "utility/HttpTool.h"
#include "IOServer.h"
#include <string>
using std::string;

namespace enet
{


class HttpIOHandler:public IOHandler
{
public:
    HttpIOHandler(enet::IOServer *io_server, int idle_ms)
        :IOHandler(io_server, idle_ms)
    {
    }
    virtual ~HttpIOHandler(){}

    virtual IOStatus OnRead(int fd, uint64_t now_ms);
    virtual IOStatus OnWrite(int fd, uint64_t now_ms);
    virtual IOStatus OnError(int fd, uint64_t now_ms);

public:
    bool SetRoot(const char *path);

protected:
    string m_root;
    bool ReadFile(const char*path, ByteBuffer &byte_buffer);  //读取path文件到byte_buffer

protected:
    virtual bool OnHttpReq(int fd, HttpReq &req);  //处理http请求
private:
    DECL_LOGGER(logger);
};

}//namespace
#endif /* HTTP_IOHANDLER_H_ */
