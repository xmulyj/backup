/*
 * BinaryIOHandler.h
 *
 *  Created on: 2014-9-27
 *      Author: yongjinliu
 */

#ifndef BINARY_IOHANDLER_H_
#define BINARY_IOHANDLER_H_

#include "IOServer.h"
#include "Packet.h"

#include <string>
using std::string;

namespace enet
{


class BinaryIOHandler:public IOHandler
{
public:
    typedef enum  _send_mode_
    {
        SEND_SYNC,
        SEND_ASYNC,
    }SendMode;
public:
    BinaryIOHandler():IOHandler(),m_packet(NULL){}
    BinaryIOHandler(enet::IOServer *io_server, int idle_ms);
    virtual ~BinaryIOHandler(){}

    void SetPacket(Packet *packet){m_packet = packet;}
    Packet* GetPacket(){return m_packet;}

    virtual IOStatus OnRead(int fd, uint64_t now_ms);
    virtual IOStatus OnWrite(int fd, uint64_t now_ms);
    virtual IOStatus OnError(int fd, uint64_t now_ms);
protected:
    virtual bool OnPacket(int fd, uint32_t cmd, const char *packet_data, uint32_t head_size, uint32_t body_size);

    //发送数据
    bool SendContextData(int fd);  //通过IOContext异步发送
    virtual bool SendData(int fd, char *data, uint32_t size, SendMode send_mode=SEND_SYNC);
    virtual void OnSendFailed(int fd);
    virtual void OnSendSucc(int fd);
private:
    Packet *m_packet;
private:
    DECL_LOGGER(logger);
};

}//namespace
#endif /* BINARY_IOHANDLER_H_ */
