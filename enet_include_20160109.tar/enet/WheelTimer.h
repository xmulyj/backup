/*
 * Timer.h
 *
 *  Created on: May 18, 2014
 *      Author: young
 */

#ifndef WHEELTIMER_H_
#define WHEELTIMER_H_
#include <stddef.h>
#include <stdint.h>
#include <vector>
using std::vector;

#include "ObjectPool.h"
#include "Logger.h"

namespace enet
{

#define WHEEL_SLOT_NUM  64   //每个轮的刻度数
#define WHEEL_MS        0
#define WHEEL_SEC       1
#define WHEEL_MIN       2
#define WHEEL_HOUR      3
#define WHEEL_NUM       4

typedef struct _timer_node_
{
	void    *user_data;
	int32_t internal_ms;
	struct _timer_node_ *next;
	struct _timer_node_ *pre;
}TimerNode,*TimerID;

typedef struct _timer_wheel_
{
	int index;
	TimerNode slot[WHEEL_SLOT_NUM];
}TimerWheel;

class WheelTimer
{
public:
	WheelTimer();
	void Start();
	TimerID Add(uint64_t expire_ms, void *user_data);
	bool Del(TimerID timer);

	int NextTimeout();  //下次超时间隔
	//本方法收集到的超时TimerID会自动回收,如果调用者保存了该TimerID(通过调用Add获取的),请不要再处理!!!
	bool CheckTimerOut(uint64_t now_ms, vector<void *> &user_data_vec);
private:
	uint64_t   m_NowTime;
	TimerWheel m_TimerWheel[WHEEL_NUM];
	ObjectPool<TimerNode> m_TimerNodePool;
private:
	DECL_LOGGER(logger);
};

inline
int WheelTimer::NextTimeout()
{
	int count = 0; 
	for(int i=m_TimerWheel[WHEEL_MS].index; count<10; i=(i+1)%WHEEL_SLOT_NUM,++count)
		if(m_TimerWheel[WHEEL_MS].slot[i].next != NULL)
			break;
	return count*16;
}

}//namespace
#endif /* WHEELTIMER_H_ */
