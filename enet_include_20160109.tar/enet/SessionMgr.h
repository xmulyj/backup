/*
 * SessionMgr.h
 *
 *  Created on: 2014-12-9
 *      Author: yongjinliu
 */

#ifndef SESSION_MGR_H_
#define SESSION_MGR_H_

#include <assert.h>
#include "TCPSocket.h"
#include "IOServer.h"
#include "Logger.h"
#include "Packet.h"

#include <map>
#include <list>
#include <vector>
using std::map;
using std::list;
using std::vector;

namespace enet
{

//////////  SessionMgr:会话管理; 纯虚基类  //////////
//Session维护一个空闲的session列表
//需要时从该列表获取空闲session使用,不需要时返还给空闲列表;
class Session;
class SessionMgr: public IOHandler
{
protected:
    //创建所有(GetMaxSession返回的个数)的session实例对象
    //每个创建好的session对象必需调用AddFreeSession将其添加到空闲列表中后才能使用
    virtual bool CreateAllSession()=0;


public:  //会话基本参数
    SessionMgr()
        :m_is_block(0)
        ,m_max_session(1000)
        ,m_idle_timeout(3)
        ,m_recv_timeout(3)
        ,m_send_timeout(3)
        ,m_max_recv_size(65536)
        ,m_max_send_size(65546)
        ,m_max_req_per_sec(1000)
        ,m_user_data(NULL)
    {
    }
    virtual ~SessionMgr(){}

    //获取/设置阻塞模式
    uint32_t GetBlockMode(){return m_is_block;}
    void SetBlockMode(uint32_t block){m_is_block=block;}

    //获取/设置最大会话(连接)个数
    uint32_t GetMaxSession(){return m_max_session;}
    void SetMaxSession(uint32_t max_session){m_max_session=max_session;}

    //获取/设置空闲超时时间(秒)
    int32_t GetIdleTime(){return m_idle_timeout;}
    void SetIdleTime(int32_t idle_timeout){m_idle_timeout=idle_timeout;}

    //获取/设置接收一个完整数据包的超时时间
    int32_t GetRecvTime(){return m_recv_timeout;}
    void SetRecvTime(uint32_t recv_timeout){m_recv_timeout=recv_timeout;}

    //获取/设置发送一个完整数据包的超时时间
    int32_t GetSendTime(){return m_send_timeout;}
    void SetSendTime(uint32_t send_timeout){m_send_timeout=send_timeout;}

    //获取/设置接收一个完整数据包的最大缓冲区大小
    int32_t GetMaxRecvSize(){return m_max_recv_size;}
    void SetMaxRecvSize(uint32_t max_recv_size){m_max_recv_size=max_recv_size;}

    //获取/设置发送一个完整数据包的最大缓冲区大小
    int32_t GetMaxSendSize(){return m_max_send_size;}
    void SetMaxSendSize(uint32_t max_send_size){m_max_send_size=max_send_size;}

    //获取/设置每秒最大请求个数(请求频率控制)
    int32_t GetMaxReqPerSec(){return m_max_req_per_sec;}
    void SetMaxReqPerSec(uint32_t max_req_per_sec){m_max_req_per_sec = max_req_per_sec;}
    
    //获取/设置用户数据
    void* GetUserData(){return m_user_data;}
    void SetUserData(void *user_data){m_user_data=user_data;}


public:  //会话管理
    //从空闲列表获取新的会话并且和fd绑定.没有空闲会话或者错误等失败返回NULL
    Session* GetSession(int fd);

    //释放会话,和fd解除绑定关系并归还到空闲列表
    bool ReleaseSession(Session *session);

    //查找和fd绑定的会话,没有找到返回NULL
    Session* FindSession(int fd);


protected:
    //将新创建的session添加到空闲队列,有CreateAllSession调用
    void AddFreeSession(Session *session);

    //初始化需要绑定的fd(这边强制设置fd为非阻塞模式的,其实最好应该是让创建fd的地方来初始化)
    virtual bool InitAttribute(int fd);


private:
    uint32_t m_is_block;        //是否阻塞
    uint32_t m_max_session;     //会话最大个数
    int32_t m_idle_timeout;     //空闲超时时间(单位:秒)
    int32_t m_recv_timeout;     //接收超时时间(单位:秒)
    int32_t m_send_timeout;     //发送超时时间(单位:秒)
    int32_t m_max_recv_size;    //缓冲区最大接收大小
    int32_t m_max_send_size;    //缓冲区最大发送大小
    int32_t m_max_req_per_sec;  //每秒最大请求个数(频率控制,0表示不控制)
    void *m_user_data;          //传给session的用户数据


private:
    //空闲会话列表
    typedef std::list<Session*> FreeSessionList;
    typedef typename FreeSessionList::iterator FreeSessionListIt;
    FreeSessionList m_free_session_list;

    //使用中会话列表
    typedef std::map<int/*fd*/, Session*> UsedSessionMap;
    typedef typename UsedSessionMap::iterator UsedSessionMapIt;
    UsedSessionMap  m_used_session_map;


public:  //重写IOHandler的纯虚函数
    virtual IOStatus OnRead(int fd, uint64_t now_ms){return IO_ERROR;}
    virtual IOStatus OnWrite(int fd, uint64_t now_ms){return IO_ERROR;}
    virtual IOStatus OnError(int fd, uint64_t now_ms){return IO_ERROR;}


private:
    DECL_LOGGER(logger);
};

//////////  Session  //////////
class Session
{
public:
    Session()
        :m_session_mgr(NULL)
        ,m_idle_timeout(0)
        ,m_recv_timeout(0)
        ,m_send_timeout(0)
        ,m_max_recv_size(0)
        ,m_max_send_size(0)
        ,m_max_req_per_sec(0)
        ,m_user_data(NULL)
        //下面三个是动态的
        ,m_fd(-1)
        ,m_recv_begin_time(0)
        ,m_send_begin_time(0)
    {
    }
    virtual ~Session(){}

    // 释放session,之后session就不能再用了
    virtual void Release()
    {
        if(m_session_mgr != NULL)
        {
            m_session_mgr->ReleaseSession(this);
        }

        m_fd = -1;
        m_recv_timeout = 0;
        m_recv_begin_time = 0;
    }

    // 会话管理器
    void SetSessionMgr(SessionMgr *session_mgr){m_session_mgr = session_mgr;}
    SessionMgr* GetSessionMgr(){return m_session_mgr;}

    // 空闲超时时间(秒)
    void SetIdleTimeout(uint32_t idle_timeout){m_idle_timeout = idle_timeout;}
    uint32_t GetIdleTimeout(){return m_idle_timeout;}

    // 数据包接收超时时间
    void SetRecvTimeout(uint32_t recv_timeout){m_recv_timeout = recv_timeout;}
    uint32_t GetRecvTimeout(){return m_recv_timeout;}

    // 数据包发送超时时间
    void SetSendTimeout(uint32_t send_timeout){m_send_timeout = send_timeout;}
    uint32_t GetSendTimeout(){return m_send_timeout;}

    // 最大接收长度
    void SetMaxRecvSize(uint32_t max_recv_size){m_max_recv_size = max_recv_size;}
    uint32_t GetMaxRecvSize(){return m_max_recv_size;}

    // 最大发送长度
    void SetMaxSendSize(uint32_t max_send_size){m_max_send_size = max_send_size;}
    uint32_t GetMaxSendSize(){return m_max_send_size;}

    uint32_t GetMaxReqPerSec(){return m_max_req_per_sec;}
    void SetMaxReqPerSec(uint32_t max_req_per_sec){m_max_req_per_sec = max_req_per_sec;}

    // 设置用户数据
    void SetUserData(void *user_data){m_user_data = user_data;}
    void* GetUserData(){return m_user_data;}

    // 设置/获取fd
    int GetFD(){return m_fd;}
    void SetFD(int fd){m_fd = fd;}

    // 数据包首次接收时间
    void SetRecvBeginTime(uint32_t recv_begin_time){m_recv_begin_time = recv_begin_time;}
    uint32_t GetRecvBeginTime(){return m_recv_begin_time;}

    // 数据包首次发送时间
    void SetSendBeginTime(uint32_t send_begin_time){m_send_begin_time = send_begin_time;}
    uint32_t GetSendBeginTime(){return m_send_begin_time;}


    // 接收是否超时
    bool IsRecvTimeout()
    {
        if(m_recv_timeout == 0)
            return false;
        uint32_t now = time(NULL);
        if(m_recv_begin_time+m_recv_timeout < now)
            return true;
        else
            return false;
    }

    bool IsRecvTimeout(uint32_t now)
    {
        if(m_recv_timeout == 0)
            return false;
        if(m_recv_begin_time+m_recv_timeout > now)
            return false;
        else
            return true;
    }

    // 发送是否超时
    bool IsSendTimeout()
    {
        if(m_send_timeout == 0)
            return false;
        uint32_t now = time(NULL);
        if(m_send_begin_time+m_send_timeout < now)
            return true;
        else
            return false;
    }
    bool IsSendTimeout(uint32_t now)
    {
        if(m_send_timeout == 0)
            return false;
        if(m_send_begin_time+m_send_timeout > now)
            return false;
        else
            return true;
    }

private:
    SessionMgr *m_session_mgr;
    uint32_t m_idle_timeout;    //空闲超时事件(单位:秒,0时不检查操作超时)
    uint32_t m_recv_timeout;    //接收超时时间(单位:秒,0时不检查操作超时)
    uint32_t m_send_timeout;    //发送超时时间(单位:秒,0时不检查操作超时)
    uint32_t m_max_recv_size;   //缓冲区最大接收大小
    uint32_t m_max_send_size;   //缓冲区最大发送大小
    uint32_t m_max_req_per_sec; //每秒最大请求个数(流量控制,0表示不控制)
    void *m_user_data;          //应用程序数据

    //下面三个是动态的
    int m_fd;                   //socket fd
    uint32_t m_recv_begin_time; //接收开始时间
    uint32_t m_send_begin_time; //发送开始时间
};


//////////  SessionMgrDefault:默认的实现的会话管理  //////////
//添加:绑定某个listen_fd,当该listen_fd有新的连接时分配一个空闲的session对象和该新连接绑定.
template <typename SessionDefaultType>
class SessionMgrDefault: public SessionMgr
{
public:
    SessionMgrDefault()
        :m_is_inited(false)
        ,m_listen_fd(0)
        ,m_packet(NULL)
    {
    }
    virtual ~SessionMgrDefault(){}

    //用于连接的
    void Init(IOServer *io_server, Packet *packet)
    {
        assert(m_is_inited==false && io_server!=NULL && packet!=NULL);
        m_is_inited = true;
        m_packet = packet;
        //初始化父类
        IOHandler::Init(io_server, TIME_INFINITY);

        //创建空闲会话
        bool ret = CreateAllSession();
        assert(ret == true);
    }

    //用于监听的
    void Init(IOServer *io_server, Packet *packet, uint32_t listen_fd)
    {
        assert(m_is_inited==false && listen_fd>0 && io_server!=NULL && packet!=NULL);
        m_is_inited = true;
        m_packet = packet;
        //初始化父类
        IOHandler::Init(io_server, TIME_INFINITY);

        //创建空闲会话
        bool ret = CreateAllSession();
        assert(ret == true);

        //添加监听fd的事件
        m_listen_fd = listen_fd;
        if(!GetBlockMode())
        {
            if(TCPSocket::SetNoBlock(m_listen_fd) != 0)
            {
                LOG_WARN(logger, "set listen fd NoBlock failed.fd="<<m_listen_fd);
            }
        }
        std::pair<IOEvent,IOEvent> ret_pair = GetIOServer()->AddEvent(m_listen_fd, EVENT_READ, this);
        assert(ret_pair.first != EVENT_EMPTY);
    }

    //获取打包器
    Packet* GetPacket(){return m_packet;}
     //获取绑定的listen_fd
    uint32_t GetListenFD(){return m_listen_fd;}


public:  //重写IOHandler的纯虚函数
    IOStatus OnRead(int fd, uint64_t now_ms)  //如果绑定了listen_fd,则该listen_fd可读标示有新的连接请求
    {
        uint32_t is_block = GetBlockMode();
        do
        {
            struct sockaddr_in peer_addr;
            int conn = TCPSocket::Accept(m_listen_fd, peer_addr);
            if(conn == -1)
            {
                break;
            }
            if(CheckConnect(conn, peer_addr) != true)
            {
                LOG_WARN(logger, "OnRead:check connect return failed.close it.fd="<<conn<<",peer="<<inet_ntoa(peer_addr.sin_addr));
                close(conn);
            }
            else
            {
                //设置新连接对应的session
                SessionDefaultType *session = dynamic_cast<SessionDefaultType*>(GetSession(conn));
                if(session == NULL)
                {
                    LOG_ERROR(logger, "OnRead:add session failed.close it.fd="<<conn<<",peer="<<inet_ntoa(peer_addr.sin_addr));
                    close(conn);
                    //break;  //不要break, 否则有的连接可能接收不了(epoll的边缘触发模式)
                    continue;
                }
                //((IOHandler*)session)->SetIdleTime(SessionMgr::GetIdleTime()*1000);
                ((IOHandler*)session)->Init(GetIOServer(), SessionMgr::GetIdleTime()*1000);
                LOG_INFO(logger, "OnRead:accept new connection:fd="<<conn<<",session="<<session<<",peer="<<inet_ntoa(peer_addr.sin_addr));

                /* 添加新连接的可读事件 */
                std::pair<IOEvent, IOEvent> ret_pair = GetIOServer()->AddEvent(conn, EVENT_READ, session);
                if(ret_pair.first == EVENT_EMPTY)
                {
                    LOG_ERROR(logger, "OnRead:add WRITE event to io server failed.close it.fd="<<conn);
                    ReleaseSession(session);
                    close(conn);
                    //break;  //不要break, 否则有的连接可能接收不了(epoll的边缘触发模式)
                }
            }
        }while(!is_block);

        return IO_CONTINUE;
    }
    //IOStatus OnWrite(int fd, uint64_t now_ms){return IO_ERROR;}
    //IOStatus OnError(int fd, uint64_t now_ms){close(fd);return IO_ERROR;}


protected:  //实现基类SessionMgr的纯虚函数
    virtual bool CreateAllSession()
    {
        uint32_t size = GetMaxSession();
        m_session_vec.resize(size);
        for(int i=0; i<size; ++i)
        {
            m_session_vec[i].SetPacket(GetPacket());
            AddFreeSession(&m_session_vec[i]);
        }
        return true;
    }

    //检查连接情况(比如是否允许连接等)
    virtual bool CheckConnect(int conn, const struct sockaddr_in &peer_addr)
    {
        return true;
    }
private:
    vector<SessionDefaultType> m_session_vec;

    bool m_is_inited;           //是否已经初始化过
    uint32_t m_listen_fd;       //监听的fd
    Packet * m_packet;          //打包器
private:
    DECL_LOGGER(logger);
};
IMPL_LOGGER_TEMPLATE(SessionMgrDefault, logger, SessionType);




//////////  SessionDefault  //////////
class SessionDefault: public Session, public IOHandler
{
public:  //实现IOHandler的纯虚函数
    virtual IOStatus OnRead(int fd, uint64_t now_ms);
    virtual IOStatus OnWrite(int fd, uint64_t now_ms);
    virtual IOStatus OnError(int fd, uint64_t now_ms); //请不要close掉fd,框架会close的.切记切记!!!

    //重写Session的方法
    virtual void Release();

protected: /* 子类需要根据实际情况重写本方法 */
    virtual bool OnPacket(uint32_t cmd, const char *packet_data, uint32_t head_size, uint32_t body_size, uint64_t tid)
    {
        LOG_DEBUG(logger, "SessionDefault OnPacket|CMD="<<cmd<<",HeadSize="<<head_size<<",BodySize="<<body_size<<"Tid="<<tid<<".fd="<<GetFD());
        return true;
    }

public:
    SessionDefault()
        :m_packet(NULL)
        ,m_recv_head_size(0)
        ,m_recv_body_size(0)
        ,m_send_size(0)
        ,m_cur_req_num(0)
        ,m_cur_req_time_ms(0)
    {
    }
    virtual ~SessionDefault()
    {
        m_packet = NULL;
        m_recv_buffer.Clear();
        m_recv_head_size = 0;
        m_recv_body_size = 0;
        m_send_buffer.Clear();
        m_send_size = 0;
    }

    Packet* GetPacket(){return m_packet;}
    void SetPacket(Packet *packet){m_packet = packet;}

    /* 是否有数据待发送 */
    bool HaveWaitToSend()
    {
        return m_send_size<m_send_buffer.Size()?true:false;
    }

    /* 发送数据说明:
        1. 同步发送:直接用TCPSocket发送就可以了
        2. 异步发送:
            a) 直接调用带参数的AsyncSend方法:没有数据等待发送的时候尝试直接发,如果没有发送完成则添加到buffer里面异步发送;
            b) 获取SendBuffer操作缓冲区设置数据,然后调用不带参数的AsyncSend方法;
        3. 应用层也可以先同步发送数据,没有发送完再用异步发送(这个有点麻烦).
        (同步发送前应该判断是否有等待的数据,没有的话才可以发送)
        (异步发送其实会先尝试直接发送,发送不了再异步发送)
        (对发送数据长度做了限制)
    */
    /* 获取发送的反冲区 */
    ByteBuffer& GetSendBuffer(){return m_send_buffer;}
    /* 异步发送缓冲区中的数据 */
    bool AsyncSend();
    /* 异步发送数据,成功返回true(成功不是表示数据都发送出去了,而是发送到buffer里面去;同步发送的话直接用TCPSocket发送就可以了) */
    bool AsyncSend(const char *data, uint32_t size);
protected:
    /* 发送缓冲区中的数据,返回剩余数据.错误返回-1(只简单发送数据,不做其他检查) */
    int SendBufferData();
    int _SendData(const char *data, uint32_t size);

    /* 读数据到缓冲区,返回接收数据大小.错误返回-1(只简单接收数据,不做其他检查) */
    int RecvBufferData();
private:
    Packet * m_packet;
    ByteBuffer m_recv_buffer;  //接收缓冲区
    uint32_t m_recv_head_size; //已经接收到的协议头部大小
    uint32_t m_recv_body_size; //已经接收到的协议体大小

    ByteBuffer m_send_buffer;  //发送缓冲区
    uint32_t m_send_size;      //已经发送的数据大小
    
    //请求频率控制
    uint32_t m_cur_req_num;    //已经接收到的请求个数(达到每秒最大请求个数之后会重置)
    uint64_t m_cur_req_time_ms;   //接收第一个请求的时间(达到每秒最大请求个数之后会重置)
    
    //检查请求频率.返回false表示请求频率超过设置值
    bool CheckReqFrequency(uint64_t now_ms);
private:
    DECL_LOGGER(logger);
};

} /* namespace */
#endif /* SESSION_MGR_H_ */
