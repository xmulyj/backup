/*
 * IAcceptor.h
 *
 * Created on: 2014-7-14
 * Author: yongjinliu
 */
#ifndef IACCEPTOR_H_
#define IACCEPTOR_H_
#include <assert.h>
#include "TCPSocket.h"
#include "IOServer.h"
#include "Logger.h"

namespace enet
{

class Acceptor: public IOHandler
{
public:
    Acceptor()
            : m_listen_fd(-1), m_io_handler(NULL), m_is_block(false)
    {
    }
    Acceptor(IOServer *io_server, int listen_fd, IOHandler *io_handler)
            : IOHandler(io_server, TIME_INFINITY), m_listen_fd(listen_fd), m_io_handler(
                    io_handler)
    {
        assert(m_io_handler != NULL);
        m_is_block = TCPSocket::IsBlock(m_listen_fd);
        std::pair<IOEvent, IOEvent> ret_pair = GetIOServer()->AddEvent(m_listen_fd, EVENT_READ, this);
        assert(ret_pair.first != EVENT_EMPTY);
    }
    void Init(IOServer *io_server, int listen_fd, IOHandler *io_handler)
    {
        IOHandler::Init(io_server, TIME_INFINITY);
        assert(io_handler != NULL);
        m_listen_fd = listen_fd;
        m_io_handler = io_handler;
        m_is_block = TCPSocket::IsBlock(m_listen_fd);
        std::pair<IOEvent, IOEvent> ret_pair = GetIOServer()->AddEvent(m_listen_fd, EVENT_READ, this);
        assert(ret_pair.first != EVENT_EMPTY);
    }
    IOStatus OnRead(int fd, uint64_t now_ms);
    IOStatus OnWrite(int fd, uint64_t now_ms)
    {
        return IO_ERROR;
    }
    IOStatus OnError(int fd, uint64_t now_ms)
    {
        close(fd);
        return IO_ERROR;
    }
protected:
//通知收到新的链接请求
    virtual bool OnConnect(int fd, const struct sockaddr_in &peer_addr)
    {
        return true;
    }
private:
    int m_listen_fd;
    int m_is_block;
    IOHandler *m_io_handler;
private:
    DECL_LOGGER(logger)
    ;
};
/*
inline IOStatus Acceptor::OnRead(int fd, uint64_t now_ms)
{
    bool has_error = false;
    do
    {
        struct sockaddr_in peer_addr;
        int conn = TCPSocket::Accept(m_listen_fd, peer_addr);
        if (conn == -1)
        {
            break;
        }
        if (!m_is_block)
        {
            if (!TCPSocket::SetNoBlock(conn))
            {
                close(conn);
                has_error = true;
            }
        }
        std::pair<IOEvent, IOEvent> ret_pair = GetIOServer()->AddEvent(conn,
                EVENT_READ, m_io_handler);
        if (ret_pair.first == EVENT_EMPTY)
        {
            close(conn);
            has_error = true;
        }
        if (!OnConnect(conn, peer_addr))
        {
            close(conn);
            has_error = true;
        }
    } while (!has_error && !m_is_block);
    return IO_SUCC;
}
*/
} //namespace
#endif /* IACCEPTOR_H_ */
